#from django.shortcuts import render
from django.http import HttpResponse


def index(request):
    return HttpResponse("HELLO DJANGO!")


def add_article(request):
    return HttpResponse("TEST!")
